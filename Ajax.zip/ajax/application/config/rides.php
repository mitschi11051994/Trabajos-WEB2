<?php
$config['use_google_maps'] = 'true';
$config['google_key'] = 'AIzaSyB9vXGCxF4cIRV5UYfAXtfMoC58qLPlDEQ';
